# open_jtalk

[![C/C++ CI](https://github.com/r9y9/open_jtalk/actions/workflows/ccpp.yaml/badge.svg)](https://github.com/r9y9/open_jtalk/actions/workflows/ccpp.yaml)

A fork of open_jtalk based on v1.10.

## Why

Wanted to fork it with *git*.

**NOTE**: To preserve history of cvs version of open_jtalk, this fork was originially created by:

```
git cvsimport -v \
  -d :pserver:anonymous@open-jtalk.cvs.sourceforge.net:/cvsroot/open-jtalk \
  -C open_jtalk open_jtalk
```
