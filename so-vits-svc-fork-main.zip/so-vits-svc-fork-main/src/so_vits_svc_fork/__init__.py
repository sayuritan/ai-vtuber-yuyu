__version__ = "4.2.26"

from .logger import init_logger

init_logger()
